﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistrySystem
{
    [Serializable()]
    public abstract class RegistryObject : Game.Engine.EventDispatcher
    {
        public List<string> children = new List<string>();
        public string my_id, parent_id;
    }
}
